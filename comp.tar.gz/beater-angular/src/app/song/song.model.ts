export interface Song {
  id: string
  name: string
  album: string
  author: string
  rating: string
  genre: string
}
