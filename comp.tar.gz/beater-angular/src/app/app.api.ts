export const MEAT_API = 'http://localhost:3000'
