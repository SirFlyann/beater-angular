import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'mt-restaurant-detail',
  templateUrl: './restaurant-detail.component.html'
})
export class RestaurantDetailComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
